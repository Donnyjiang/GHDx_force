This example demonstrates incorporating the d3 lasso plugin with a d3 scatterplot. Clicking and dragging on the plot area will produce a lasso that can be used to hover or loop around the dots in the scatterplot. Functions are then executed based on whether dots were selected or not.

The lasso plugin can be found [here](https://github.com/skokenes/D3-Lasso-Plugin).